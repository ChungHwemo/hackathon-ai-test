# Project-K AI - アーキテクチャドキュメント

> CAINZ Hackathon - 統合開発プラットフォーム
> 最終更新日: 2026-02-06

## 概要

Project-K AIは、Atlassian（JIRA/Confluence）、Microsoft Teams、GitHub、Google Gemini AIを統合し、一般的な開発ワークフローを自動化する開発者生産性向上プラットフォームです。

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Project-K AI Platform                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                        Frontend (React + Vite)                          │ │
│  │  /web                                                                   │ │
│  │  ├── Dashboard        - システム概要 & 設定状況                         │ │
│  │  ├── JIRA Automation  - AI駆動チケット生成                              │ │
│  │  ├── Knowledge Search - 統合検索（4ソース）                             │ │
│  │  ├── PR Review        - 自動コードレビュー                              │ │
│  │  └── Error Log Search - エラー分析 & ソリューション                     │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                      │                                       │
│                                      ▼                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                    Vite Dev Server Middleware                           │ │
│  │  /web/vite.config.ts                                                    │ │
│  │  ├── /api/search      → Confluence + JIRA + Teams 検索                  │ │
│  │  ├── /api/jira        → チケット作成 + Confluenceページ                 │ │
│  │  ├── /api/pr-review   → GitHub PR + Geminiレビュー                      │ │
│  │  ├── /api/teams       → Teamsメッセージ検索                             │ │
│  │  ├── /api/web-search  → Serper Web検索                                  │ │
│  │  └── /api/error-log   → エラー分析 + JIRA検索                           │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                      │                                       │
│                                      ▼                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                         External Services                               │ │
│  │  ├── Atlassian Cloud (JIRA + Confluence)                                │ │
│  │  ├── Microsoft Teams (Graph API)                                        │ │
│  │  ├── GitHub API                                                         │ │
│  │  ├── Google Gemini AI                                                   │ │
│  │  └── Serper (Web検索)                                                   │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## ディレクトリ構成

```
hackathon-ai-test/
├── docs/                               # ドキュメント
│   ├── README.md                       # ドキュメントハブ
│   ├── setup/                          # セットアップ
│   │   ├── QUICKSTART.md               # クイックスタート
│   │   └── ENVIRONMENT.md              # 環境変数リファレンス
│   ├── architecture/                   # アーキテクチャ
│   │   ├── OVERVIEW.md                 # 概要
│   │   ├── FRONTEND.md                 # フロントエンド
│   │   ├── BACKEND.md                  # バックエンド
│   │   └── API.md                      # APIリファレンス
│   ├── features/                       # 機能ドキュメント
│   │   ├── JIRA_AUTOMATION.md
│   │   ├── KNOWLEDGE_SEARCH.md
│   │   ├── PR_REVIEW.md
│   │   └── ERROR_LOG.md
│   └── status/                         # ステータス
│       └── CURRENT.md                  # 現在の状況
│
├── src/                                # バックエンドライブラリ（TypeScript）
│   ├── index.ts                        # エントリポイント
│   ├── shared/
│   │   ├── types/index.ts              # 共通型定義
│   │   ├── clients/                    # APIクライアント
│   │   │   ├── index.ts
│   │   │   ├── jira-client.ts          # JIRA REST API v3
│   │   │   ├── confluence-client.ts    # Confluence REST API v2
│   │   │   ├── gemini-client.ts        # Google Generative AI
│   │   │   └── github-client.ts        # GitHub REST API
│   │   └── utils/
│   │       └── query-escape.ts         # クエリエスケープユーティリティ
│   │
│   └── plugins/                        # 機能モジュール
│       ├── dashboard/
│       ├── jira-automation/
│       │   └── ticket-generator.ts
│       ├── knowledge-search/
│       │   └── searcher.ts
│       ├── error-log-search/
│       │   ├── classifier.ts
│       │   └── searcher.ts
│       └── pr-review/
│           └── reviewer.ts
│
├── web/                                # フロントエンド（React + Vite）
│   ├── src/
│   │   ├── App.tsx                     # React Routerセットアップ
│   │   ├── main.tsx                    # エントリポイント
│   │   ├── index.css                   # グローバルスタイル
│   │   │
│   │   ├── pages/                      # ページコンポーネント
│   │   │   ├── dashboard.tsx           # 設定状況表示付き
│   │   │   ├── jira-automation.tsx
│   │   │   ├── knowledge-search.tsx
│   │   │   ├── pr-review.tsx           # API統合済み
│   │   │   └── error-log-search.tsx
│   │   │
│   │   ├── services/                   # APIサービスレイヤー
│   │   │   ├── api.ts                  # JIRA自動化API
│   │   │   ├── knowledge-api.ts        # ナレッジ検索API
│   │   │   ├── pr-review-api.ts        # PRレビューAPI ★新規
│   │   │   ├── teams-api.ts            # Microsoft Teams API ★新規
│   │   │   ├── confluence-integration.ts # Confluence統合
│   │   │   ├── error-log-api.ts        # エラーログAPI
│   │   │   └── search-query-builder.ts # クエリビルダー
│   │   │
│   │   ├── hooks/                      # カスタムReactフック
│   │   │   ├── useI18n.tsx             # 国際化フック
│   │   │   ├── useParallelSearch.ts    # 並列検索オーケストレーション ★新規
│   │   │   └── use-mobile.ts           # モバイル検出
│   │   │
│   │   ├── components/                 # UIコンポーネント
│   │   │   ├── layout/                 # アプリシェル
│   │   │   │   ├── sidebar.tsx
│   │   │   │   └── app-layout.tsx
│   │   │   └── ui/                     # shadcn/uiコンポーネント
│   │   │
│   │   ├── types/                      # フロントエンド型定義
│   │   │   ├── knowledge-search.ts
│   │   │   ├── teams.ts                # Teams型 ★新規
│   │   │   └── template-settings.ts
│   │   │
│   │   ├── locales/                    # i18n翻訳
│   │   │   ├── ja.json                 # 日本語
│   │   │   └── en.json                 # 英語
│   │   │
│   │   └── lib/
│   │       └── utils.ts                # Tailwindユーティリティ
│   │
│   └── vite.config.ts                  # Vite設定 + APIミドルウェア
│
├── tests/                              # テストファイル
│   ├── jira-client.test.ts
│   ├── confluence-client.test.ts
│   ├── ticket-generator.test.ts
│   ├── knowledge-searcher.test.ts
│   ├── query-escape.test.ts
│   └── search-query-builder.test.ts
│
├── scripts/
│   └── seed-confluence-docs.ts
│
├── package.json
├── vitest.config.ts
└── .env
```

---

## 技術スタック

### フロントエンド
| 技術 | バージョン | 用途 |
|------|-----------|------|
| React | 19.x | UIフレームワーク |
| Vite | 7.x | ビルドツール + 開発サーバー |
| TypeScript | 5.9 | 型安全性 |
| Tailwind CSS | 4.x | スタイリング |
| shadcn/ui | latest | コンポーネントライブラリ |
| React Router | 7.x | クライアントサイドルーティング |
| Lucide React | latest | アイコン |

### バックエンド（ライブラリ）
| 技術 | バージョン | 用途 |
|------|-----------|------|
| TypeScript | 5.6 | 型安全性 |
| Zod | 3.x | ランタイムバリデーション |
| @google/generative-ai | 0.21 | Gemini APIクライアント |

### テスト
| 技術 | 用途 |
|------|------|
| Vitest | ユニットテスト（96テスト通過） |

### 外部サービス
| サービス | APIバージョン | 用途 |
|---------|--------------|------|
| Atlassian Cloud | JIRA v3, Confluence v2 | 課題管理、ドキュメント |
| Microsoft Teams | Graph API | メッセージ検索 |
| GitHub | REST API v3 | PRデータ、差分取得 |
| Google Gemini | v1beta | AIテキスト生成 |
| Serper | REST | Web検索 |

---

## アーキテクチャパターン

### 1. Viteミドルウェアパターン（現行）

フロントエンド開発サーバーが`vite.config.ts`のカスタムミドルウェアプラグイン経由でAPIリクエストを直接処理します。

```typescript
// web/vite.config.ts
{
  name: 'api-proxy',
  configureServer(server) {
    server.middlewares.use('/api/search', async (req, res, next) => {
      // Atlassian/Teams APIを直接呼び出し
    })
  }
}
```

**メリット:**
- ハッカソン/プロトタイピング向けのシンプルな構成
- 別プロセスのバックエンドが不要
- API変更時のホットリロード対応

**デメリット:**
- 本番環境には非対応（クラスタリング、レート制限なし）
- `src/`のバックエンドライブラリがフロントエンドから使用されていない
- `vite.config.ts`と`src/plugins/`でロジックが重複

### 2. 並列検索パターン（useParallelSearch）

複数のソースを同時に検索し、結果を段階的に表示します。

```typescript
// web/src/hooks/useParallelSearch.ts
const { results, isLoading, progress, aiSummary, search } = useParallelSearch()

// 4つのソースを並列で検索
// 1. Confluence (CQL)
// 2. JIRA (JQL)
// 3. Teams (Graph API)
// 4. Web (Serper)
```

### 3. 共有クライアント

`src/shared/clients/`内の再利用可能なAPIクライアント:

| クライアント | ファイル | メソッド |
|-------------|---------|---------|
| JiraClient | `jira-client.ts` | `searchIssues()`, `createIssue()`, `searchInProject()` |
| ConfluenceClient | `confluence-client.ts` | `searchPages()`, `searchInSpace()`, `createPage()`, `upsertPage()` |
| GeminiClient | `gemini-client.ts` | `generateText()`, `chat()` |
| GithubClient | `github-client.ts` | `getPullRequest()`, `getPullRequestFiles()` |

---

## データフロー

### ナレッジ検索フロー（並列検索）

```
ユーザークエリ
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ Frontend: useParallelSearch                                  │
│ 1. 4つの並列検索を発火                                       │
│    ├── Confluence (CQL)                                      │
│    ├── JIRA (JQL)                                            │
│    ├── Teams (Graph API)                                     │
│    └── Web (Serper)                                          │
│ 2. 結果を段階的にマージ                                      │
│ 3. 完了時にAI統合を実行                                      │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ Vite Middleware: /api/search, /api/teams, /api/web-search   │
│ - 各外部APIにルーティング                                    │
│ - 認証処理                                                   │
│ - レスポンス正規化                                           │
└─────────────────────────────────────────────────────────────┘
```

### JIRA自動化フロー

```
ユーザーリクエスト（自然言語）
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ Frontend: jira-automation.tsx                               │
│ 1. ユーザーが機能要求を入力                                  │
│ 2. バイリンガルリクエストを検出（英語でも、in English）       │
│ 3. generateTickets() → Gemini を呼び出し                    │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ Frontend: api.ts（Gemini直接呼び出し）                       │
│ 1. JIRAチケット形式でプロンプトを構築                        │
│ 2. 検出された場合はバイリンガル指示を追加                    │
│ 3. JSONレスポンスを解析 → TicketDraft[]                     │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ Vite Middleware: /api/jira                                  │
│ 1. 選択されたチケットを受信                                  │
│ 2. ループ: JIRA API経由で各課題を作成                        │
│ 3. オプション: Confluenceページを自動作成                    │
│ 4. 作成されたチケットキー + URLを返却                        │
└─────────────────────────────────────────────────────────────┘
```

---

## 環境変数

```bash
# Atlassian Cloud（必須）
VITE_ATLASSIAN_DOMAIN=your-domain      # 例: "cainz"
VITE_ATLASSIAN_EMAIL=user@example.com
VITE_ATLASSIAN_API_TOKEN=xxx
VITE_JIRA_PROJECT_KEY=KWA

# Confluence（オプション - 自動ページ作成用）
VITE_CONFLUENCE_SPACE_ID=your-space-id

# GitHub（PRレビュー用）
VITE_GITHUB_TOKEN=ghp_xxx

# Google Gemini（必須）
VITE_GEMINI_API_KEY=xxx
VITE_GEMINI_MODEL=gemini-2.5-flash

# Microsoft Teams（オプション）
VITE_TEAMS_TENANT_ID=xxx
VITE_TEAMS_CLIENT_ID=xxx
VITE_TEAMS_CLIENT_SECRET=xxx
VITE_TEAMS_TEAM_ID=xxx

# Web検索（オプション）
VITE_SERPER_API_KEY=xxx
```

---

## 現在の実装状況

| 機能 | フロントエンド | バックエンドAPI | 外部連携 | ステータス |
|-----|--------------|---------------|---------|----------|
| ダッシュボード | ✅ 完全 | N/A | N/A | ✅ 完了 |
| JIRA自動化 | ✅ 完全 | ✅ /api/jira | ✅ JIRA + Gemini | ✅ 完了 |
| ナレッジ検索 | ✅ 完全 | ✅ /api/search | ✅ Confluence + JIRA | ✅ 完了 |
| - Teams検索 | ✅ 完全 | ✅ /api/teams | ⚠️ Azure設定必要 | 🟡 一部 |
| - Web検索 | ✅ 完全 | ✅ /api/web-search | ⚠️ Serperキー必要 | 🟡 一部 |
| - AI統合 | ✅ | N/A | ✅ Gemini | ✅ |
| PRレビュー | ✅ 完全 | ✅ /api/pr-review | ✅ GitHub + Gemini | ✅ 完了 |
| エラーログ | ✅ UI | ⚠️ 未接続 | モックデータ | 🟡 一部 |
| Confluence自動作成 | ✅ | ✅ | ⚠️ Space ID必要 | 🟡 一部 |

### テスト状況

```
Test Files  12 passed (12)
     Tests  96 passed (96)
  Duration  1.21s
```

---

## 拡張ガイド

### 新しい検索ソースの追加

**ステップ1: APIサービスを作成**
```typescript
// web/src/services/new-source-api.ts
export async function searchNewSource(query: string): Promise<SearchResult[]> {
  const response = await fetch('/api/new-source', {
    method: 'POST',
    body: JSON.stringify({ query })
  });
  return response.json();
}
```

**ステップ2: useParallelSearchを更新**
```typescript
// web/src/hooks/useParallelSearch.ts
// 新しいソースを並列検索に追加
```

**ステップ3: Viteミドルウェアに追加**
```typescript
// web/vite.config.ts
server.middlewares.use('/api/new-source', handler);
```

---

## 本番環境の考慮事項

### 現在の制限事項（ハッカソンモード）
- Viteミドルウェアは開発専用
- 認証/認可なし
- レート制限なし
- APIキーがVITE_プレフィックスで公開

### 推奨される本番アーキテクチャ

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   React SPA     │────▶│   API Gateway   │────▶│  Backend API    │
│  (Static Host)  │     │  (Auth, Rate)   │     │  (Node/Express) │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                                                        │
                                                        ▼
                                              ┌─────────────────┐
                                              │  src/plugins/*  │
                                              │  (コード再利用)  │
                                              └─────────────────┘
```

---

## 参考資料

- [JIRA REST API v3](https://developer.atlassian.com/cloud/jira/platform/rest/v3/)
- [Confluence REST API v2](https://developer.atlassian.com/cloud/confluence/rest/v2/)
- [GitHub REST API](https://docs.github.com/en/rest)
- [Google Gemini API](https://ai.google.dev/gemini-api/docs)
- [Microsoft Graph - Teams](https://learn.microsoft.com/en-us/graph/api/resources/teams-api-overview)
- [Serper API](https://serper.dev/docs)
