# Project-K AI - 아키텍처 문서

> CAINZ Hackathon - 통합 개발 플랫폼
> 최종 업데이트: 2026-02-06

## 개요

Project-K AI는 Atlassian(JIRA/Confluence), Microsoft Teams, GitHub, Google Gemini AI를 통합하여 일반적인 개발 워크플로우를 자동화하는 개발자 생산성 향상 플랫폼입니다.

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                              Project-K AI Platform                            │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │                        Frontend (React + Vite)                           │ │
│  │  /web                                                                    │ │
│  │  ├── Dashboard        - 시스템 개요 & 설정 상태                           │ │
│  │  ├── JIRA Automation  - AI 기반 티켓 생성                                 │ │
│  │  ├── Knowledge Search - 통합 검색 (4개 소스)                              │ │
│  │  ├── PR Review        - 자동 코드 리뷰                                    │ │
│  │  └── Error Log Search - 에러 분석 & 솔루션                                │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                       │                                       │
│                                       ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │                    Vite Dev Server Middleware                            │ │
│  │  /web/vite.config.ts                                                     │ │
│  │  ├── /api/search      → Confluence + JIRA + Teams 검색                   │ │
│  │  ├── /api/jira        → 티켓 생성 + Confluence 페이지                    │ │
│  │  ├── /api/pr-review   → GitHub PR + Gemini 리뷰                          │ │
│  │  ├── /api/teams       → Teams 메시지 검색                                 │ │
│  │  ├── /api/web-search  → Serper 웹 검색                                    │ │
│  │  └── /api/error-log   → 에러 분석 + JIRA 검색                             │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                       │                                       │
│                                       ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │                         External Services                                │ │
│  │  ├── Atlassian Cloud (JIRA + Confluence)                                 │ │
│  │  ├── Microsoft Teams (Graph API)                                         │ │
│  │  ├── GitHub API                                                          │ │
│  │  ├── Google Gemini AI                                                    │ │
│  │  └── Serper (웹 검색)                                                    │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## 디렉토리 구조

```
hackathon-ai-test/
├── docs/                               # 문서
│   ├── README.md                       # 문서 허브
│   ├── setup/                          # 설정
│   │   ├── QUICKSTART.md               # 퀵스타트
│   │   └── ENVIRONMENT.md              # 환경 변수 레퍼런스
│   ├── architecture/                   # 아키텍처
│   │   ├── OVERVIEW.md                 # 개요
│   │   ├── FRONTEND.md                 # 프론트엔드
│   │   ├── BACKEND.md                  # 백엔드
│   │   └── API.md                      # API 레퍼런스
│   ├── features/                       # 기능 문서
│   │   ├── JIRA_AUTOMATION.md
│   │   ├── KNOWLEDGE_SEARCH.md
│   │   ├── PR_REVIEW.md
│   │   └── ERROR_LOG.md
│   └── status/                         # 상태
│       └── CURRENT.md                  # 현재 상태
│
├── src/                                # 백엔드 라이브러리 (TypeScript)
│   ├── index.ts                        # 진입점
│   ├── shared/
│   │   ├── types/index.ts              # 공통 타입 정의
│   │   ├── clients/                    # API 클라이언트
│   │   │   ├── index.ts
│   │   │   ├── jira-client.ts          # JIRA REST API v3
│   │   │   ├── confluence-client.ts    # Confluence REST API v2
│   │   │   ├── gemini-client.ts        # Google Generative AI
│   │   │   └── github-client.ts        # GitHub REST API
│   │   └── utils/
│   │       └── query-escape.ts         # 쿼리 이스케이프 유틸리티
│   │
│   └── plugins/                        # 기능 모듈
│       ├── dashboard/
│       ├── jira-automation/
│       │   └── ticket-generator.ts
│       ├── knowledge-search/
│       │   └── searcher.ts
│       ├── error-log-search/
│       │   ├── classifier.ts
│       │   └── searcher.ts
│       └── pr-review/
│           └── reviewer.ts
│
├── web/                                # 프론트엔드 (React + Vite)
│   ├── src/
│   │   ├── App.tsx                     # React Router 설정
│   │   ├── main.tsx                    # 진입점
│   │   ├── index.css                   # 글로벌 스타일
│   │   │
│   │   ├── pages/                      # 페이지 컴포넌트
│   │   │   ├── dashboard.tsx           # 설정 상태 표시 포함
│   │   │   ├── jira-automation.tsx
│   │   │   ├── knowledge-search.tsx
│   │   │   ├── pr-review.tsx           # API 통합 완료
│   │   │   └── error-log-search.tsx
│   │   │
│   │   ├── services/                   # API 서비스 레이어
│   │   │   ├── api.ts                  # JIRA 자동화 API
│   │   │   ├── knowledge-api.ts        # 지식 검색 API
│   │   │   ├── pr-review-api.ts        # PR 리뷰 API ★신규
│   │   │   ├── teams-api.ts            # Microsoft Teams API ★신규
│   │   │   ├── confluence-integration.ts # Confluence 통합
│   │   │   ├── error-log-api.ts        # 에러 로그 API
│   │   │   └── search-query-builder.ts # 쿼리 빌더
│   │   │
│   │   ├── hooks/                      # 커스텀 React 훅
│   │   │   ├── useI18n.tsx             # 국제화 훅
│   │   │   ├── useParallelSearch.ts    # 병렬 검색 오케스트레이션 ★신규
│   │   │   └── use-mobile.ts           # 모바일 감지
│   │   │
│   │   ├── components/                 # UI 컴포넌트
│   │   │   ├── layout/                 # 앱 셸
│   │   │   │   ├── sidebar.tsx
│   │   │   │   └── app-layout.tsx
│   │   │   └── ui/                     # shadcn/ui 컴포넌트
│   │   │
│   │   ├── types/                      # 프론트엔드 타입 정의
│   │   │   ├── knowledge-search.ts
│   │   │   ├── teams.ts                # Teams 타입 ★신규
│   │   │   └── template-settings.ts
│   │   │
│   │   ├── locales/                    # i18n 번역
│   │   │   ├── ja.json                 # 일본어
│   │   │   └── en.json                 # 영어
│   │   │
│   │   └── lib/
│   │       └── utils.ts                # Tailwind 유틸리티
│   │
│   └── vite.config.ts                  # Vite 설정 + API 미들웨어
│
├── tests/                              # 테스트 파일
│   ├── jira-client.test.ts
│   ├── confluence-client.test.ts
│   ├── ticket-generator.test.ts
│   ├── knowledge-searcher.test.ts
│   ├── query-escape.test.ts
│   └── search-query-builder.test.ts
│
├── scripts/
│   └── seed-confluence-docs.ts
│
├── package.json
├── vitest.config.ts
└── .env
```

---

## 기술 스택

### 프론트엔드
| 기술 | 버전 | 용도 |
|-----|------|-----|
| React | 19.x | UI 프레임워크 |
| Vite | 7.x | 빌드 도구 + 개발 서버 |
| TypeScript | 5.9 | 타입 안정성 |
| Tailwind CSS | 4.x | 스타일링 |
| shadcn/ui | latest | 컴포넌트 라이브러리 |
| React Router | 7.x | 클라이언트 사이드 라우팅 |
| Lucide React | latest | 아이콘 |

### 백엔드 (라이브러리)
| 기술 | 버전 | 용도 |
|-----|------|-----|
| TypeScript | 5.6 | 타입 안정성 |
| Zod | 3.x | 런타임 유효성 검사 |
| @google/generative-ai | 0.21 | Gemini API 클라이언트 |

### 테스트
| 기술 | 용도 |
|-----|-----|
| Vitest | 유닛 테스트 (96개 테스트 통과) |

### 외부 서비스
| 서비스 | API 버전 | 용도 |
|-------|---------|-----|
| Atlassian Cloud | JIRA v3, Confluence v2 | 이슈 관리, 문서화 |
| Microsoft Teams | Graph API | 메시지 검색 |
| GitHub | REST API v3 | PR 데이터, Diff |
| Google Gemini | v1beta | AI 텍스트 생성 |
| Serper | REST | 웹 검색 |

---

## 아키텍처 패턴

### 1. Vite 미들웨어 패턴 (현재)

프론트엔드 개발 서버가 `vite.config.ts`의 커스텀 미들웨어 플러그인을 통해 API 요청을 직접 처리합니다.

```typescript
// web/vite.config.ts
{
  name: 'api-proxy',
  configureServer(server) {
    server.middlewares.use('/api/search', async (req, res, next) => {
      // Atlassian/Teams API 직접 호출
    })
  }
}
```

**장점:**
- 해커톤/프로토타이핑에 적합한 간단한 구성
- 별도 백엔드 프로세스 불필요
- API 변경 시 핫 리로드 지원

**단점:**
- 프로덕션 환경에 부적합 (클러스터링, 레이트 제한 없음)
- `src/`의 백엔드 라이브러리가 프론트엔드에서 사용되지 않음
- `vite.config.ts`와 `src/plugins/` 간 로직 중복

### 2. 병렬 검색 패턴 (useParallelSearch)

여러 소스를 동시에 검색하고 결과를 점진적으로 표시합니다.

```typescript
// web/src/hooks/useParallelSearch.ts
const { results, isLoading, progress, aiSummary, search } = useParallelSearch()

// 4개 소스를 병렬로 검색
// 1. Confluence (CQL)
// 2. JIRA (JQL)
// 3. Teams (Graph API)
// 4. Web (Serper)
```

### 3. 공유 클라이언트

`src/shared/clients/`의 재사용 가능한 API 클라이언트:

| 클라이언트 | 파일 | 메서드 |
|-----------|-----|--------|
| JiraClient | `jira-client.ts` | `searchIssues()`, `createIssue()`, `searchInProject()` |
| ConfluenceClient | `confluence-client.ts` | `searchPages()`, `searchInSpace()`, `createPage()`, `upsertPage()` |
| GeminiClient | `gemini-client.ts` | `generateText()`, `chat()` |
| GithubClient | `github-client.ts` | `getPullRequest()`, `getPullRequestFiles()` |

---

## 데이터 흐름

### 지식 검색 흐름 (병렬 검색)

```
사용자 쿼리
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ Frontend: useParallelSearch                                  │
│ 1. 4개의 병렬 검색 실행                                       │
│    ├── Confluence (CQL)                                      │
│    ├── JIRA (JQL)                                            │
│    ├── Teams (Graph API)                                     │
│    └── Web (Serper)                                          │
│ 2. 결과를 점진적으로 병합                                     │
│ 3. 완료 시 AI 통합 실행                                       │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ Vite Middleware: /api/search, /api/teams, /api/web-search   │
│ - 각 외부 API로 라우팅                                        │
│ - 인증 처리                                                   │
│ - 응답 정규화                                                 │
└─────────────────────────────────────────────────────────────┘
```

### JIRA 자동화 흐름

```
사용자 요청 (자연어)
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ Frontend: jira-automation.tsx                               │
│ 1. 사용자가 기능 요청 입력                                   │
│ 2. 이중 언어 요청 감지 (英語でも, in English)                │
│ 3. generateTickets() → Gemini 호출                          │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ Frontend: api.ts (Gemini 직접 호출)                          │
│ 1. JIRA 티켓 형식으로 프롬프트 구성                          │
│ 2. 감지 시 이중 언어 지시 추가                               │
│ 3. JSON 응답 파싱 → TicketDraft[]                           │
└─────────────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│ Vite Middleware: /api/jira                                  │
│ 1. 선택된 티켓 수신                                          │
│ 2. 루프: JIRA API로 각 이슈 생성                             │
│ 3. 옵션: Confluence 페이지 자동 생성                         │
│ 4. 생성된 티켓 키 + URL 반환                                 │
└─────────────────────────────────────────────────────────────┘
```

---

## 환경 변수

```bash
# Atlassian Cloud (필수)
VITE_ATLASSIAN_DOMAIN=your-domain      # 예: "cainz"
VITE_ATLASSIAN_EMAIL=user@example.com
VITE_ATLASSIAN_API_TOKEN=xxx
VITE_JIRA_PROJECT_KEY=KWA

# Confluence (선택 - 자동 페이지 생성용)
VITE_CONFLUENCE_SPACE_ID=your-space-id

# GitHub (PR 리뷰용)
VITE_GITHUB_TOKEN=ghp_xxx

# Google Gemini (필수)
VITE_GEMINI_API_KEY=xxx
VITE_GEMINI_MODEL=gemini-2.5-flash

# Microsoft Teams (선택)
VITE_TEAMS_TENANT_ID=xxx
VITE_TEAMS_CLIENT_ID=xxx
VITE_TEAMS_CLIENT_SECRET=xxx
VITE_TEAMS_TEAM_ID=xxx

# 웹 검색 (선택)
VITE_SERPER_API_KEY=xxx
```

---

## 현재 구현 상태

| 기능 | 프론트엔드 | 백엔드 API | 외부 연동 | 상태 |
|-----|----------|-----------|---------|-----|
| 대시보드 | ✅ 완전 | N/A | N/A | ✅ 완료 |
| JIRA 자동화 | ✅ 완전 | ✅ /api/jira | ✅ JIRA + Gemini | ✅ 완료 |
| 지식 검색 | ✅ 완전 | ✅ /api/search | ✅ Confluence + JIRA | ✅ 완료 |
| - Teams 검색 | ✅ 완전 | ✅ /api/teams | ⚠️ Azure 설정 필요 | 🟡 일부 |
| - 웹 검색 | ✅ 완전 | ✅ /api/web-search | ⚠️ Serper 키 필요 | 🟡 일부 |
| - AI 통합 | ✅ | N/A | ✅ Gemini | ✅ |
| PR 리뷰 | ✅ 완전 | ✅ /api/pr-review | ✅ GitHub + Gemini | ✅ 완료 |
| 에러 로그 | ✅ UI | ⚠️ 미연결 | 목 데이터 | 🟡 일부 |
| Confluence 자동 생성 | ✅ | ✅ | ⚠️ Space ID 필요 | 🟡 일부 |

### 테스트 상태

```
Test Files  12 passed (12)
     Tests  96 passed (96)
  Duration  1.21s
```

---

## 확장 가이드

### 새로운 검색 소스 추가

**단계 1: API 서비스 생성**
```typescript
// web/src/services/new-source-api.ts
export async function searchNewSource(query: string): Promise<SearchResult[]> {
  const response = await fetch('/api/new-source', {
    method: 'POST',
    body: JSON.stringify({ query })
  });
  return response.json();
}
```

**단계 2: useParallelSearch 업데이트**
```typescript
// web/src/hooks/useParallelSearch.ts
// 새로운 소스를 병렬 검색에 추가
```

**단계 3: Vite 미들웨어에 추가**
```typescript
// web/vite.config.ts
server.middlewares.use('/api/new-source', handler);
```

---

## 프로덕션 고려사항

### 현재 제한사항 (해커톤 모드)
- Vite 미들웨어는 개발 전용
- 인증/인가 없음
- 레이트 제한 없음
- API 키가 VITE_ 접두사로 노출됨

### 권장 프로덕션 아키텍처

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   React SPA     │────▶│   API Gateway   │────▶│  Backend API    │
│  (Static Host)  │     │  (Auth, Rate)   │     │  (Node/Express) │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                                                        │
                                                        ▼
                                              ┌─────────────────┐
                                              │  src/plugins/*  │
                                              │  (코드 재사용)   │
                                              └─────────────────┘
```

---

## 참고 자료

- [JIRA REST API v3](https://developer.atlassian.com/cloud/jira/platform/rest/v3/)
- [Confluence REST API v2](https://developer.atlassian.com/cloud/confluence/rest/v2/)
- [GitHub REST API](https://docs.github.com/en/rest)
- [Google Gemini API](https://ai.google.dev/gemini-api/docs)
- [Microsoft Graph - Teams](https://learn.microsoft.com/en-us/graph/api/resources/teams-api-overview)
- [Serper API](https://serper.dev/docs)
